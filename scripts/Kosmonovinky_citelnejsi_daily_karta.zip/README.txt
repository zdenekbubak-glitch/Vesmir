Čitelnější denní karta – 31. 10. 2026

Na GitHubu nahraďte jediný soubor scripts/generate_x_card.py a potvrďte commit.
Příští běh denního workflow použije větší písmo a kratší zobrazený text.
Soubor nahled.jpg je jen ukázka dnešní novinky; nenahrávejte ho do repozitáře.

Písmo textu: 26 → 32 px. Řádkování: 38 → 44 px.
V ověřeném náhledu dnešní karty se zobrazí přibližně o 32 % méně znaků.
Rozsah závisí na délce titulku a zalomení slov; text se krátí na hranici slova
a končí třemi tečkami. Titulek, logo, barvy, rozměr 1200 × 675 a patička
zůstávají zachované. Články ani doprovodný text příspěvků se touto úpravou nekrátí.
Nepřidává se volání AI ani změna workflow. Dříve odeslané karty se nepřepisují.
